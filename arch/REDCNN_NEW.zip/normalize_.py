import os
import argparse
import numpy as np
import pydicom
import PIL
from PIL import Image
import matplotlib.pyplot as plt
def normalize_(image,norm_range_max,norm_range_min):
    # image = image * (norm_range_max - norm_range_min) + norm_range_min
    image = (image - norm_range_min) / (norm_range_max - norm_range_min)
    return image


def trunc(mat,trunc_min,trunc_max):
    mat[mat <= trunc_min] = trunc_min
    mat[mat >= trunc_max] = trunc_max
    return mat

def save_dataset(args):
    if not os.path.exists(args.data_path):
        os.makedirs(args.data_path)
        print('Create path : {}'.format(args.data_path))
    if not os.path.exists(args.data_path1):
        os.makedirs(args.data_path1)
        print('Create path : {}'.format(args.data_path1))
    a = []

    filenames = os.listdir(args.data_path)
    # print('filenames1=', filenames)
    filenames.sort(key=lambda x: int(x[5:-11]))
    # print('filenames2=', filenames)  # 100_result.npy
    for i in filenames:
        name1 = os.path.join(args.data_path, i)
        a.append(name1)
        # print('a=',a)
    for i1 in range(len(a)):
        b0 = np.load(a[i1])

        x1 = normalize_(b0,3072.0,-1024.0)
        x1 = trunc(x1,0.0,1.0)
        np.save(os.path.join(args.data_path1,  'LDCT_{}_target'.format(i1+0)), x1)
        # print(b0.shape[-1])

        # io.savemat(os.path.join(args.data_path1, f_name), pp)

    # print(b.shape)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='D:/tyf/dataset/fakedata/test/')
    parser.add_argument('--data_path1', type=str, default='D:/tyf/dataset/fakedata/test1/')
    args = parser.parse_args()
    save_dataset(args)
