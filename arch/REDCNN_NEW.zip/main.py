import os
# os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import argparse
from torch.backends import cudnn
from loader import get_loader
from solver import Solver
import torch
torch.backends.cudnn.enabled = False
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
def main(args):
    # cudnn.benchmark = True   # DICOM
    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)
        print('Create path : {}'.format(args.save_path))

    if args.result_fig:

        fig_path = os.path.join(args.save_path, 'fig')
        x_path = os.path.join(args.save_path, 'x')
        y_path = os.path.join(args.save_path, 'y')
        pred_path = os.path.join(args.save_path, 'pred')
        if not os.path.exists(fig_path):
            os.makedirs(fig_path)
            print('Create path : {}'.format(fig_path))
        if not os.path.exists(x_path):
            os.makedirs(x_path)
            print('Create path : {}'.format(x_path))
        if not os.path.exists(y_path):
            os.makedirs(y_path)
            print('Create path : {}'.format(y_path))
        if not os.path.exists(pred_path):
            os.makedirs(pred_path)
            print('Create path : {}'.format(pred_path))
        if not os.path.exists(fig_path):
            os.makedirs(fig_path)
            print('Create path : {}'.format(fig_path))


        x_path = os.path.join(args.save_path, 'x')
        y_path = os.path.join(args.save_path, 'y')
        pred_path = os.path.join(args.save_path, 'pred')
        if not os.path.exists(fig_path):
            os.makedirs(fig_path)
            print('Create path : {}'.format(fig_path))
        if not os.path.exists(x_path):
            os.makedirs(x_path)
            print('Create path : {}'.format(x_path))
        if not os.path.exists(y_path):
            os.makedirs(y_path)
            print('Create path : {}'.format(y_path))
        if not os.path.exists(pred_path):
            os.makedirs(pred_path)
            print('Create path : {}'.format(pred_path))

    data_loader = get_loader(mode=args.mode,
                             load_mode=args.load_mode,
                             saved_path=args.saved_path,
                             test_patient=args.test_patient,
                             patch_n=(args.patch_n if args.mode=='train' else None),
                             patch_size=(args.patch_size if args.mode=='train' else None),
                             transform=args.transform,
                             batch_size=(args.batch_size if args.mode=='train' else 1),
                             num_workers=args.num_workers)

    solver = Solver(args, data_loader)
    if args.mode == 'train':
        solver.train()
    elif args.mode == 'test':
        solver.test()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument('--mode', type=str, default='test', help="train | test")
    parser.add_argument('--load_mode', type=int, default=0)
    # parser.add_argument('--saved_path', type=str, default='E:/limei/AAPM(train)_6/')
    # parser.add_argument('--saved_path', type=str, default='D:/王继平/合成结果/20220208结果/test2/')
    parser.add_argument('--saved_path', type=str, default='D:/tyf/dataset/AAPMdata/test')#D:/tyf/dataset/fakedata/test1/ D:/tyf/dataset/fakedata/train1/
    parser.add_argument('--save_path', type=str, default='./save3/')

    parser.add_argument('--test_patient', type=str, default='L')# TEST DL DCT
    parser.add_argument('--result_fig', type=bool, default=True)

    parser.add_argument('--norm_range_min', type=float, default=-1024.0)#
    parser.add_argument('--norm_range_max', type=float, default=3072.0)#
    parser.add_argument('--trunc_min', type=float, default=-1024.0)
    parser.add_argument('--trunc_max', type=float, default=3072.0)

    parser.add_argument('--transform', type=bool, default=False)
    # if patch training, batch size is (--patch_n * --batch_size)
    parser.add_argument('--patch_n', type=int, default=20)  # 10
    parser.add_argument('--patch_size', type=int, default=80)  # 64
    parser.add_argument('--batch_size', type=int, default=1)  # 16

    parser.add_argument('--num_epochs', type=int, default=100)
    parser.add_argument('--print_iters', type=int, default=20)
    parser.add_argument('--decay_iters', type=int, default=4300*15)
    parser.add_argument('--save_iters', type=int, default=4300)
    parser.add_argument('--test_iters', type=int, default=4300*93)  # 50000

    parser.add_argument('--lr', type=float, default=1e-4)  # 1e-5

    parser.add_argument('--device', type=str)
    parser.add_argument('--num_workers', type=int, default=0)
    parser.add_argument('--multi_gpu', type=bool, default=False)

    args = parser.parse_args()
    main(args)
